console.log("hi，同学，祝贺你喜提彩蛋~\n冷羊网(www.shadowsocks9.com)\n现在招聘nodejs前端开发工程师，请投简历 ggyangxing@gmail.com");

//window.$crisp=[];window.CRISP_WEBSITE_ID="44cb21f7-fd9e-42cc-8c11-5a3e01ebe39a";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.chat/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();

// live chat
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5b67fe01df040c3e9e0c517c/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
